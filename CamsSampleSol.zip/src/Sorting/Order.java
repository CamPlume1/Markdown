package Sorting;

public enum Order {
    ASCENDING, DESCENDING, TIME;


}
